package interfaces;


public interface Team
{
	public abstract void createTeam(int teamno,int a,int b);
	
}