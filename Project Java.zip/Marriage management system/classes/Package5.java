
package classes;
public class Package5
{
	public String decoration = "High Range Decoration ( Including Lighting,Flowers,Palki,Stage,Pandal) ";
	public String foodItem = "**Coffee at the Reception**Kacchi,Beef,Kabab,Roast,Jorda,Borhani,Finni,Coke/Sprite/Fanta";
	public String venue = "High---Capacity = 1000 People";
	
	public int package5Cost = 300000;
	public Package5(){}
	public void showPackageInfo(){
		System.out.println("\t\t\tDecoration = "+decoration);
		System.out.println("\t\t\tFood Item = "+foodItem);
		System.out.println("\t\t\tVenue = "+venue);
		System.out.println("\t\t\tTotal Cost : "+package5Cost);
		System.out.println(" ");
	}
}